module.exports = require('./lib/tjbot');
